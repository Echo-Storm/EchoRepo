from . import weather
from . import config
from . import utils
from . import api

def Main():
	startup = True
	utils.log(f'Starting service ...')
	utils.setsetting('service', 'idle')
	utils.log(config.addon_info, 3)

	# Geolocation
	if not utils.geoip() and not utils.setting('loc1'):
		utils.geoip(True)
		utils.setsetting('service', 'running')
		weather.Main('1', mode='geoip')
		weather.Main('1', mode='download')
		utils.setsetting('service', 'idle')

	# Service
	while not utils.monitor.abortRequested():
		utils.setsetting('service', 'running')

		# Init
		if utils.settingrpc('weather.addon') == 'weather.kodiweather':
			utils.log(f'Running service ...', 3)

			if not startup:
				config.init(cache=True)

			start   = utils.time.time()
			current = utils.settingrpc("weather.currentlocation") or 1  # fallback: loc1 if RPC fails

			# On startup, immediately push cached data to window properties so
			# the skin background appears at once, before any network activity.
			# This runs in under a second (file reads only, no network).
			# The download + second update below will refresh with live data.
			if startup:
				utils.log('Startup: pre-loading properties from cache ...', 3)
				weather.Main(str(current), mode='update')

			# Download
			for locid in range(1, config.addon.maxlocs):
				if utils.monitor.abortRequested():
					break
				if utils.setting(f'loc{locid}'):
					weather.Main(str(locid), mode='download')

			# Update
			if not utils.monitor.abortRequested():
				weather.Main(str(current), mode='update')
			utils.setsetting('service', 'idle')

			# Notification
			if not utils.monitor.abortRequested():
				if startup or utils.lastupdate('alert_notification') >= utils.setting('alert_interval', 'int') * 60:
					utils.setupdate('alert_notification')

					# Queue - alerts only for the currently selected location
					if utils.setting(f'loc{current}') and utils.setting(f'loc{current}alert', 'bool'):
						weather.Main(str(current), mode='msgqueue')

					# Send
					if not utils.monitor.abortRequested():
						weather.Main(str(current), mode='msgsend')

			# Finish
			utils.log(f'Finished ({round(utils.time.time() - start, 3)} sec)', 3)

		else:
			utils.log('Addon not enabled ...', 4)
			utils.setsetting('service', 'idle')

		# Sleep
		startup = False
		utils.monitor.waitForAbort(300)

	utils.log(f'Stopping service ...')
	api.s.close()

